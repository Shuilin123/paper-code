%imdec_OL2.m
%image decomposition model from 'Dual Norms and Image Decomposition Models'
%Date: 9/16/2012

path(path, 'toolbox/');
path(path, 'image1/');
path(path,'contourlet_toolbox/');
path(path,'./smoothn');
path(path,'CurveLab-2.0.1/')
path(path,'contourlet_toolbox/')
path(path,'./CurveLab-2.0.1/fdct_wrapping_matlab')
path(path,'./shearlet_toolbox_1')
path(path,'./BM3D/BM3D')
clc
clear all
close all

imgRaw = double(imread('.\image5\NORMAL-139386-4.jpeg'));
imgRaw = imgRaw/255;
% M_Pure3 = rescale(load_image('.\image5\p2N_mu_1000_lambda_ 100_tau0.1_iter5_Nor_NA100_BL.bmp',512));
% M_Pure = M_Pure3(:,:,1);
%M_Pure3 = double(imread('.\image5\p2N_mu_1_lambda_ 5_tau0.1_iter5_Nor_NA50_BL.bmp'));
%M_Pure = M_Pure3(:,:,1)/255;
f = imgRaw;
u = zeros(size(f));
v = zeros(size(f));
w = zeros(size(f));

mu = 6000;
tau = 0.1;
lambda = 0.03;
IterMax = 5;
tic
for iter = 1:IterMax

%          w = 1/(5)*(f-u-v);  % L2
%          w = f-u-v-den4(f-u-v, 'db8', 3); % ����Ӧ������ֵ С��
%          w = f-u-v-ConDenoise(f-u-v); % contourlet ������
%          w = f-u-v- CuvDenoise( (f-u-v) *255,15)/255; % curvelet ����
%          w = f-u-v-shearletDenoise( (f-u-v )*255,15)/255; % shearlet
          [NA, I_denoised] = BM3D(1, f-u-v, 40);
          w = f-u-v - I_denoised; %BM3D
          v = proj(f-u-w,tau,mu);
          u = smoothn(f-v-w,lambda); %smoothn method,BL function

%u = f-v-w-proj(f-v-w,tau,lambda);
   u11=u+v;
   Max1=max(max(u11(10:510,10:510)));
   Min1=min(min(u11(10:510,10:510)));
   uv1=(u11(10:510,10:510)-Min1) / ( Max1-Min1);
   % fprintf('snr = %f\n',snr(M_Pure(10:510,10:510),uv1));
end
toc
figure
imshow(u+v,[])

u11=u+v;
u11 =real(u11);
Max1=max(max(u11));
Min1=min(min(u11));
u2=(u11-Min1) / ( Max1-Min1);
u3=u2*255;
imwrite(uint8(u3),['..\�Ա�TV_G_BM3D\NORMAL\','pic4_mu_6000_lambda_0.03_tau0.1_iter5_Nor_NA40_BL.bmp'])

% u11=u;
% u11 =real(u11);
% Max1=max(max(u11));
% Min1=min(min(u11));
% u2=(u11-Min1) / ( Max1-Min1);
% u3=u2*255;
% figure(1)
% imshow(uint8(u3))
% imwrite(uint8(u3),['./image3/TV_G_','BM3D','_fringe172_mu_6lambda_3_tau0.1_iter5_Nor_u.bmp'])
% 
% u11=v;
% u11 =real(u11);
% Max1=max(max(u11));
% Min1=min(min(u11));
% u2=(u11-Min1) / ( Max1-Min1);
% u3=u2*255;

% figure(2)
% imshow(uint8(u3))
% imwrite(uint8(u3),['./image3/TV_G_','BM3D','_fringe172_mu_6lambda_3_tau0.1_iter5_Nor_v.bmp'])

% u11=w;
% u11 =real(u11);
% Max1=max(max(u11));
% Min1=min(min(u11));
% u2=(u11-Min1) / ( Max1-Min1);
% u3=u2*255;
% imwrite(uint8(u3),['C:\Users\Administrator\Desktop\�Ա�TV_G_BM3D\NORMAL\','p2N_mu_1_lambda_ 5_tau0.1_iter5_Nor_NA50_BL.bmp'])