path(path,'./BM3D')
clc
clear all;
close all;

img  = double(imread('./input/cut-12.tif'));
% img = log10(10+img); % Log
HjL=img(:,:,1);
Min=min(HjL(:));
Max=max(HjL(:));
ratioTo255=255/(Max-Min);
Channel_Imageto255=(HjL-Min)*ratioTo255;
[NA, I_denoised] = BM3D(1, Channel_Imageto255, 5);%, sigma);
I_denoised=I_denoised*255/ratioTo255+Min;

% I_denoised = 10.^I_denoised - 10;%Log

figure;imshow(I_denoised,[])

u11=I_denoised;
Max1=max(max(u11));
Min1=min(min(u11));
u2=(u11-Min1) / ( Max1-Min1);
u3=u2*255;
imwrite(uint8(u3),'./output/cut-12_sig5.bmp')
