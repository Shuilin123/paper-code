function [p]=l1_pr(b,a,r)
%function [p]=l1_pr(b,a,r)
% b : original (noisy) wavelet coeffs
% a : weights
% r : radius
% p : convex projection of x 

[m,n]=size(b);
ab = abs(b);
aa = a; bb =ab;
pind = [1:n];
nind = [1:n];

while(~isempty(nind))
 %disp(size(nind));
 c = (aa*bb'-r)/(aa*aa');
 p(pind) = bb - c*aa;
 nind = find(p < 0);
 pind = find(p > 0);
 p(nind) = 0.0;
 aa = a(pind); bb = ab(pind);
end;
p =sign(b).*p;

