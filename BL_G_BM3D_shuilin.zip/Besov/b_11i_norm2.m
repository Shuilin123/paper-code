function [y]=b_11i_norm2(x)
%function [y]=b_11i_norm2(x)

[m,n]=size(x);
%scale = sqrt(2).^([0 floor(log2([1:n-1]))+1]);
scale = ones(size(x));
level = log2(n);
snorm = zeros(1,level);
xtemp = abs(x).*scale;
for k=1:level
 ei = 2^k;
 si = ei/2 + 1;
 snorm(k) = sum(sum(xtemp(si:ei,si:ei)+xtemp(1:si-1,si:ei)+xtemp(si:ei,1:si-1)));
end;
y = max(snorm) + abs(x(1,1)); 
