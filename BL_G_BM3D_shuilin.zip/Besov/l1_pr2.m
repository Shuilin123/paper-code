function [phh,phl,plh]=l1_pr2(bhh,bhl,blh,ahh,ahl,alh,r)
% function [phh,phl,plh]=l1_pr(bhh,bhl,blh,ahh,ahl,alh,r)
% bhh,bhl,blh : original (noisy) wavelet coeffs
% ahh,ahl,alh : weights
% r : radius 
% phh,phl,plh : convex projection of x 

[m,n]=size(bhh);
b = [reshape(bhh,1,m*n) reshape(bhl,1,m*n) reshape(blh,1,m*n)];
a = [reshape(ahh,1,m*n) reshape(ahl,1,m*n) reshape(alh,1,m*n)];

[p]=l1_pr(b,a,r);

b=reshape(p,m,n,3);
phh = b(:,:,1);
phl = b(:,:,2);
plh = b(:,:,3);

