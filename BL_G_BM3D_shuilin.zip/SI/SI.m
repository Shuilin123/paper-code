function s =SI(u)

% Raw=imread('t17B90M1_ced_2500ci_t0.1_New.bmp');
% I0 = double(Raw(:,:,1));
% figure
% imshow(I0,[])
% I = I0(35:542,35:734);%tu108  I0(34:543,34:735) correct
% I = I0(44:532,44:709);  %t17
% I = I0(64:513,64:687);  %tu235
% I = I0(65:642,65:817);  %tu52_Extend_M
% imwrite(uint8(I),'t17B90M1_ced_2500ci_t0.1_New_Cut.bmp')
% % figure
% imshow(I,[])

%calculate speckle index
% r=str2double(input('����Ҫ��ȥ�ı�Ե�Ĵ�С��','s'));
I = u ;
r =0 ;
[m,n]=size(I);
Imean=zeros(m,n);sigma=zeros(m,n);

for i=r+2:m-r-1
    for j=r+2:n-r-1
        Imean(i,j)=(I(i-1,j-1)+I(i-1,j)+I(i-1,j+1)+I(i,j-1)+I(i,j)+I(i,j+1)+I(i+1,j-1)+I(i+1,j)+I(i+1,j+1))/9;
        sigma(i,j)=sqrt(sum(sum((I(i-1:i+1,j-1:j+1)-Imean(i,j)).^2))./8);
    end
end
t=sigma./(Imean+0.0000001);
s=sum(sum(t))/(m*n);
% disp(['s=',num2str(s)]); 