%plot sipsnr.m

clc
clear all;
close all;

% A1 = double( imread('phase1Free.bmp') );
% A2 = double( imread('phase1TViter_200dt_0.2_0.8to0_0.005I.bmp') );
% A3 = double( imread('phase1_50ci_ZhuPhasemu_0_mu1_1lambda_0.01_0.05u_0.05f.bmp') );
% A4 = double( imread('phase1_ced_thr14_100ci_200ci_t0.1.bmp') );

A1 =  imread('tu29_4_512_sig_30w_1.2thr_120_Normal.bmp') ;
A2 =  imread('tu29_4_512_mu_5lambda_1_tau0.1_iter5_Method1_lvd_layer2_Nor.bmp') ;
A3 =  imread('tu29_4_512_mu_5_lambda_15_tau0.1_iter5_layer_2_OL1_Nor.bmp') ;
A4 =  imread('TV-H-L_tu29_4_kkk1_2_kkk2_4_lambda_1_mu_4_sig_1.5_p1_170_q48_Dx_12_tol_1_6_tol_2_6_uv.bmp') ;
A5 =  imread('TV-H-L_tu29_4_kkk1_2_kkk2_4_lambda_8_mu_4_sig_1.5_q48_Dx_12_tol_1_10_tol_2_10_uv_H1.bmp') ;

SI(A1)
SI(A2)
SI(A3)
SI(A4)
SI(A5)


  img1 = A1;
  img2 = A2;
  img3 = A3;
  img4 = A4;
  
%   K = [0.05 0.05];
%   window = ones(8);
%   L = 100;
%   [mssim1] = ssim_index(img1, img2, K, window, L);
%   [mssim2] = ssim_index(img1, img3, K, window, L);
%   [mssim3] = ssim_index(img1, img4, K, window, L);
%   mssim1
%   mssim2
%   mssim3