%plot sipsnr.m

clc
clear all;
close all;

% A1 = double( imread('phase1Free.bmp') );
% A2 = double( imread('phase1TViter_200dt_0.2_0.8to0_0.005I.bmp') );
% A3 = double( imread('phase1_50ci_ZhuPhasemu_0_mu1_1lambda_0.01_0.05u_0.05f.bmp') );
% A4 = double( imread('phase1_ced_thr14_100ci_200ci_t0.1.bmp') );

A1 =  imread('Compo3_sig_30w_1.0thr_250_Normal.bmp') ;
A2 =  imread('Compo_Improve_kkk4_kkk5_lambda4_mu8_q48_Dx12_sigma1.8_tol1_10_tol2_40_uv_H1.bmp') ;
A3 =  imread('Compo_Improve_kkk5_kkk5_lambda1_mu8_q48_Dx12_sigma1.8_p1_90_tol1_10_tol2_40_uv.bmp') ;
A4 =  imread('Compo3_mu_5_lambda_10_tau0.1_iter5_layer_2_OL1.bmp') ;
A5 =  imread('Compo3_mu_5lambda_5_tau0.1_iter5_Method1_lvd_layer2_Nor.bmp') ;

SI(A1)
SI(A2)
SI(A3)
SI(A4)
SI(A5)

figure
index=100;
plot(A1(200,:),'k-o')
hold on
plot(A2(200,:),'g-*')
plot(A3(200,:),'b-d')
% plot(A4(100,:),'c-o')
% plot(A5(100,:),'y-o')
legend('1','2','3')
  img1 = A1;
  img2 = A2;
  img3 = A3;
  img4 = A4;
  
%   K = [0.05 0.05];
%   window = ones(8);
%   L = 100;
%   [mssim1] = ssim_index(img1, img2, K, window, L);
%   [mssim2] = ssim_index(img1, img3, K, window, L);
%   [mssim3] = ssim_index(img1, img4, K, window, L);
%   mssim1
%   mssim2
%   mssim3