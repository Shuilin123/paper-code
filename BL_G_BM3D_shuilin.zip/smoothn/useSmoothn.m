clc
clear all
close all

img0 = double(imread('fringe172.bmp'));
figure;imshow(img0,[])
tic
% img1 = smoothn(img0,'robust');
img1 = smoothn(img0,500);
toc
figure;imshow(img1,[])