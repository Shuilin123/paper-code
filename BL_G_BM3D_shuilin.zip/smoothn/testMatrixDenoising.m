clc
clear all
close all

img0 = double(imread('fringe172.bmp'));
img1 = img0(1:200,1:200);
[m,n] = size(img1);
figure;imshow(img1,[])
e = ones(n*m,1);
D= spdiags([e -2*e e], -1:1, m*m, m*n);
II = speye(m*n);
lama = 1000;
LeftA = II+lama*D'*D;
RightB = reshape(img1,m*n,1);
img2 = LeftA\RightB;
img3 = reshape(img2,200,200);
figure;imshow(img3,[])