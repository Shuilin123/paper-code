%   % Cardioid
  t = linspace(0,2*pi,1000);
  x = 2*cos(t).*(1-cos(t)) + randn(size(t))*0.1;
  y = 2*sin(t).*(1-cos(t)) + randn(size(t))*0.1;
  z = smoothn(complex(x,y));
  plot(x,y,'r.',real(z),imag(z),'k','linewidth',2)
  axis equal tight