%imdec_OL1.m
% image decomposition model from OL paper ,fushu jun. f=u +v +w;
%Date:9/16/2012


path(path, 'allcode/');
path(path, 'allcode1/');
path(path,'toolbox/')

clc
clear all
close all

imgRaw = double(imread('Compo3.jpg'));
imgRaw = imgRaw/max(max(imgRaw));
f = imgRaw;
u = zeros(size(f));
v = zeros(size(f));
w = zeros(size(f));

% mu = 1000000000;
tau = 0.1;
img2 = smoothn(f);
figure;imshow(img2,[])
% lambda = 0.1;
% [m,n] = size(f);
% yipslon = meshgrid(1:n,1:m);
% yipslon1 = fftshift(yipslon)/m*2*pi;

% lambda = 5;
% S=256;
% x=-S+1:1:S;
% % x1=-S:-1;
% % x2=1:S;
% % x =[x1,x2];
% x= x/max(x);
% [X,Y] = meshgrid(x,x);
% yipslon =sqrt( X.^2+Y.^2);
% yipslon1 = yipslon;
% % n=512;
% % eta = 0.001;
% % x = [0:n/2-1, -n/2:-1]/n;
% % [Y,X] = meshgrid(x,x);
% % W = 1 ./ (eta + sqrt((X.^2 + Y.^2)));
% % W= fftshift(W);
% 
% 
% IterMax = 5;
% tic
% for iter = 1:IterMax
% % w = f-u-v-WST(f-u-v,delat);
% % w = f-u-v-waveletSoftThreshold(f-u-v, 'mu', 0.15, 'lmax', 2, 'basis', 'dddtcwt');
% %   w = f-u-v-den4(f-u-v, 'db8', 3); % ����Ӧ������ֵ
% % w = f-u-v-waveletSoftThreshold(f-u-v);
% %  [thr,sorh,keepapp,crit] = ddencmp('den','wp',f-u-v);
% %   w = f-u-v-wpdencmp(f-u-v,sorh,3,'sym4',crit,thr,keepapp);
% % 
% % thr    = Donoho(f-u-v);                                            % ����Donohoȫ����ֵ
% % w      = f-u-v-wdenoise(f-u-v, 'gbl', 's', thr, 'db8', 3);              % ����ֵ���� Donoho ȫ����ֵ
% % [C, S]      = wavedec2(f-u-v, 2, 'db8');
% % thr_lvd     = Birge_Massart(C, S);                                  % ����Bige-Massa������ֵ
% % w = f-u-v-wdenoise(f-u-v, 'lvd', 's', thr_lvd, 'db8', 2);           % ����ֵ���� Donoho ȫ����ֵ
% 
% % v = Pg(f-u-w);
% % p1 = zeros(size(f));
% % p2 = zeros(size(f));  
% % n1 = 0;
% % while n1<=100
% %   [Fx,Fy] = grad( div(p1,p2)-(f-u-w)/lambda );
% %   absG = sqrt( Fx.^2+Fy.^2 ); 
% %   p1 = ( p1 + tau*Fx ) ./(1 +  tau*absG );
% %   p2 = ( p2 + tau*Fy ) ./(1 +  tau*absG );
% %   n1 = n1+1;
% % end
% % v = lambda*div(p1,p2);
% % v = proj(f,tau,mu);
% fre = fftshift(fft2(f));
% fre1 = 1./(  1+4*lambda^2*( 2*pi*abs(yipslon1) ).^4  ).*fre;
% % fre1 = 1./(  1+lambda*( 2*pi*abs(yipslon1) ).^2  ).*fre;
% fre2 = ifftshift(fre1);
% u = real(ifft2(fre2));
% % v = medfilt2(v);
% % u = real(ifft2(W.^2.*fft2(f)));
% 
% end
% toc
% 
% figure
% imshow(u,[])
