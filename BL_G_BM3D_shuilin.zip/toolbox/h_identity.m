function y=h_identity(x,a,b)
y=x;