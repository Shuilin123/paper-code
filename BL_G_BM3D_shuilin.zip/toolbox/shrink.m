function [ Y ] = shrink(X,lemda )
%SHRINK Summary of this function goes here
%   Detailed explanation goes her
Y=X.*(X>lemda)-lemda.*(X>lemda)+X.*(X<-lemda)+lemda.*(X<-lemda);

end

