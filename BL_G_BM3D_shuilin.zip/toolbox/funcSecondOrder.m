function [ u ] = funcSecondOrder( fringe173O60,un1,M,mu )

orientimt002_25= fringe173O60;
[m,n]=size(orientimt002_25);
c=zeros(m,n);s=zeros(m,n);
c(:)=cos(pi/2-orientimt002_25(:));
s(:)=sin(pi/2-orientimt002_25(:));
f=M;
n=size(f,1); m=size(f,2);
n1=n-1; m1=m-1;
u=f-un1; 
ux=zeros(n,m);uy=zeros(n,m);uxx=zeros(n,m) ;uyy=zeros(n,m) ;uxy=zeros(n,m);

iter=500;
for hindex=1:iter
for i=2:n1
        for j=2:m1
            %c(i,j)=cos(orientim(i,j));s(i,j)=sin(orientim(i,j));
            ux(i,j)=(u(i+1,j)-u(i-1,j))/2;
            uy(i,j)=(u(i,j+1)-u(i,j-1))/2;
            uxx(i,j)=u(i+1,j)-2*u(i,j)+u(i-1,j);
            uyy(i,j)=u(i,j+1)-2*u(i,j)+u(i,j-1);
            uxy(i,j)=(u(i+1,j+1)-u(i-1,j+1)-u(i+1,j-1)+u(i-1,j-1))/4;
        end
end
  u = u + 0.4*( mu*(uxx.*c.^2+2*uxy.*c.*s+uyy.*s.^2) +0.0*(M-un1-u) );
end

end

