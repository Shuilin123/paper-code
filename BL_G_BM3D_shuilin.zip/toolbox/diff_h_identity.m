function y=diff_h_identity(x,a,b)
y=1;