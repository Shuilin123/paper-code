% routine to illustrate the weak convergence when
% using a filter of the form [*, 0, 0, *]

siggen5 % generate manhattan skyline signal
testsig = e1;
L = 0;
h = ortfilt('Haar'); % filter coefficients h of Haar filter
[h, g, ht, gt, sh, sg, sht, sgt] = qmf2hgs(h); % QMF filter g
disp('Haar filters'),h,g
qmf = [h(1) 0 0 h(2)]; % this will give bad cvg

figure(1), subplot(2,1,1), plot(testsig), hold on
axis([0,2048,-4,14])
title('Manhattan skyline signal')
% print -deps testsignaal.eps
disp('... type any key to continue'),pause

% add noise

noise1 = randn(size(testsig));
y = testsig +noise1;
figure(1),subplot(2,1,1), plot(y,'r'), hold off
axis([0,2048,-4,14])
title('Manhattan skyline signal with uniform noise')
% print -deps signaalSIG1wit.eps
disp('... type any key to continue'),pause

% wavelet transform

w = FWT_BIO(y,L,ht,gt,sht,sgt);
figure(1),subplot(2,1,2), plotscales(w,5,-30,30), hold on
title('wavelet transform')
% print -deps wHaar.eps
disp('... type any key to continue'),pause

% thresholding

softth = 2; w(128:2048) = WST(w(128:2048),softth); % soft threshold
yt = IWT_BIO(w,L,h,g,sh,sg);     % inverse transform
figure(1), subplot(2,1,2), plot(softth*ones(size(w)),'r--'),hold on
                           plot(-softth*ones(size(w)),'r--'),hold off
figure(1), subplot(2,1,1), plot(yt)
axis([0,2048,-2,12])
title('Reconstructed signal after soft thresholding')
% print -deps ytHaar.eps
disp('... type any key to continue'),pause

% Redo with bad Haar filters

figure(2)
h = qmf; % bad cvg filter
[h, g, ht, gt, sh, sg, sht, sgt] = qmf2hgs(h);
disp('Dilated Haar filters'),h,g

% noisy signal 

subplot(2,1,1), plot(y,'r'), hold off
axis([0,2048,-4,14])
title('Manhattan skyline signal with uniform noise')
disp('... type any key to continue'),pause

% wavelet transform

w = FWT_BIO(y,L,ht,gt,sht,sgt);
subplot(2,1,2), plotscales(w,5,-30,30), hold on
title('wavelet transform')
% print -deps  w1001.eps
disp('... type any key to continue'),pause

% thresholding

softth = 2; w(128:2048) = WST(w(128:2048),softth);
yt = IWT_BIO(w,L,h,g,sh,sg);
figure(2), subplot(2,1,2), plot(softth*ones(size(w)),'r--'),hold on
                           plot(-softth*ones(size(w)),'r--'),hold off
subplot(2,1,1), plot(yt)
axis([0,2048,-2,12])
title('Reconstructed signal after soft thresholding')
% print -deps yt1001.eps
