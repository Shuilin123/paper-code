% function [x,CF]=Compute_DUALNORM(x,p,nit)
%
% This function computes the W^{-1,p}-norm of x.
% This norm is defined by:
% ||x||_{-1,p} = min_{div g = x} ||g||_p
%
function [alpha,CF]=Compute_DUALNORM(x,p,nit)

if (abs(mean(x(:)))>1e-15)
  disp('x does not belong to X, it has non zero mean...');
  x=x-mean(x(:));
end

if (p==2)
  beta=.07;
elseif (p==1)
  beta=5;
elseif (p==Inf)
  beta=10;
end
gamma=beta;

d1=zeros(size(x));
d1(end,1)=1;d1(1,1)=-1;
d2=zeros(size(x));
d2(1,end)=1;d2(1,1)=-1;
d1h=fft2(d1);
d2h=fft2(d2);

lambda1=zeros(size(x));
lambda21=zeros(size(x));
lambda22=zeros(size(x));
g1=zeros(size(x));
g2=zeros(size(x));

den=beta*(abs(d1h).^2 + abs(d2h).^2 + 1);
CF=zeros(nit,2);
for k=1:nit
  %Step 1
  c1=d1h.*fft2(lambda1-beta*x)+fft2(-lambda21+beta*g1);
  c2=d2h.*fft2(lambda1-beta*x)+fft2(-lambda22+beta*g2);
  y1=ifft2( ( (abs(d2h).^2+1).*c1 -d1h.*conj(d2h).*c2 ) ./ den );
  y2=ifft2( ( (abs(d1h).^2+1).*c2 -d2h.*conj(d1h).*c1 ) ./ den );

  %Step 2
  g1=y1+lambda21/beta;
  g2=y2+lambda22/beta;
  
  [g1,g2]=Prox(g1,g2,1/beta,p);
  
  ng=sqrt(g1(:).^2+g2(:).^2);
  if (p==1)
    CF(k,1)=sum(ng);
  elseif (p==2)
    CF(k,1)=norm(ng);
  elseif (p==Inf)
    CF(k,1)=max(ng);
  end
  
  divy=-drond1T(y1)-drond2T(y2);
  CF(k,2)=norm(divy(:)-x(:));
  %figure(1);colormap gray(255);imagesc(divy);
  %title(sprintf('Image%i/%i -- CF:%1.2e', k,nit,CF(k)));
  %colorbar;
  
  %Step 3
  lambda1=lambda1+gamma*(divy-x);
  lambda21=lambda21+gamma*(y1-g1);
  lambda22=lambda22+gamma*(y2-g2);
end
alpha=CF(k,1);

function [g1,g2]=Prox(g1,g2,alpha,p)

if (p==1) 
  ng=sqrt(g1.^2+g2.^2);
  ng(ng==0)=1;
  g1=g1-min(alpha,ng).*g1./ng;
  g2=g2-min(alpha,ng).*g2./ng;
elseif (p==2)
  ng=sqrt(sum(g1(:).^2+g2(:).^2));
  if (ng==0) ng=1; end %#ok<SEPEX>
  g1=g1-min(alpha,ng)*g1/ng;
  g2=g2-min(alpha,ng)*g2/ng;
elseif (p==Inf)
  ng=sqrt(g1.^2+g2.^2);
  ngg=ProjectionWL1(ng,ones(size(ng)),1);
  ng(ng==0)=1;
  g11=g1./ng.*ngg;
  g12=g2./ng.*ngg;
  
  g1=alpha*(g1-g11);
  g2=alpha*(g2-g12);
end

function d=drond1T(im)
d=zeros(size(im));
d(2:end,:)=im(1:end-1,:)-im(2:end,:);
d(1,:)=im(end,:)-im(1,:);
function d=drond2T(im)
d=zeros(size(im));
d(:,2:end)=im(:,1:end-1)-im(:,2:end);
d(:,1)=im(:,end)-im(:,1);

% function [z,sigma]=ProjectionWL1(xx,L,alpha)
%
% Computes the projection of xx on a weighted l1 ball
% sigma is the threshold parameter.
% The ball is defined by {x, ||L.*x||_1 \leq \alpha}
function [z,sigma]=ProjectionWL1(xx,L,alpha)

x=xx(:);
L=L(:);
n=numel(x);

%Check if solution is non trivial
M=sum(abs(L(:).*x(:)));
if M<=alpha 
    %disp('No change')
    z=xx;
    sigma=0;
    return;
end
if alpha<=0
    disp('Are you sure of your parameters?')
    z=zeros(size(xx));
    sigma=infty;
    return;
end

%Compute the projection in the other case...
ax=abs(x(:));
w=ax./L;
[y,J]=sort(w);

E1=L(J(n))*ax(J(n));
E2=L(J(n))^2;
Ep=0;
E=E1-y(n)*E2;
%sprintf('Seuil : %f,E : %f',ax(J(n)),E)
i=n;
while( (E<alpha) && (i>1) )
    i=i-1;
    E1=E1+L(J(i))*ax(J(i));
    E2=E2+L(J(i))^2;
    Ep=E;
    E = E1-y(i)*E2;
    %disp(sprintf('Iteration:%i,Seuil : %f,E : %f',i,ax(J(i)),E));
end

if (i>1)
  a=y(i);
  b=y(i+1);
  r=(Ep-E)/(b-a);
  sigma=(alpha-(Ep-r*b))/r;
else
  sigma=(M-alpha)/E2;    
end

%sprintf('E:%f,Ep:%f,sigma:%f',E,Ep,sigma)
%sigma doit etre compris entre y(i) et y(i+1)

z=x(:);
K=find(ax<sigma*L);
if (~isempty(K))
  z(ax<sigma*L)=0;
end

K=find(ax>=sigma*L);
if (~isempty(K))
  z(K)=x(K)-sigma*sign(x(K)).*L(K);
end

%disp('Change')
z=reshape(z,size(xx));
