function u=projItera(g,t,r,N)
% m=length(g);
p01=zeros(size(g));
p02=zeros(size(g));
n=1;
while n<=N
    q0=div(p01,p02);
    u0=q0-g/r;
    [ux,uy]=grad(u0);
    V=(ux.^2+uy.^2).^(1/2);
    p11=(p01+t*ux)./(1+t*V);
    p12=(p02+t*uy)./(1+t*V);
    p01=p11;
    p02=p12;
    n=n+1;
end 
p=div(p11,p12);
u=r*p;