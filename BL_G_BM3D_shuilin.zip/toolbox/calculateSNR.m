clc 
clear all
close all
   
path(path, 'toolbox/');
path(path, 'images/');
path(path, 'image1/');
path(path, 'images/cartoons/');
path(path, 'images/textures/');

   n = 512;
   u11 = double(imread('fringe172_sig_15w_0.7thr_25_Normal.bmp'));
   Max1=max(max(u11(10:510,10:510)));
   Min1=min(min(u11(10:510,10:510)));
   uv1=(u11(10:510,10:510)-Min1) / ( Max1-Min1);
   M_Pure = rescale(load_image('./image2/fringe172Free',n));
   fprintf('snr = %f\n',snr(M_Pure(10:510,10:510),uv1));
