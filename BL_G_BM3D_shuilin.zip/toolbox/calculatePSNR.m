clc
clear all
close all

M_Pure= double(imread('./image2/fringe172Free.bmp'))/255;
u2 = double(imread('./image2/fringe172Noise_sig_30w_1.0thr_25_Normal.bmp'))/255;
u_NN = u2;
fprintf('snr = %f',snr(M_Pure,u_NN));